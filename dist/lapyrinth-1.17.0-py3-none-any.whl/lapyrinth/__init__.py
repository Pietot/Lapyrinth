from .lapyrinth import Maze
from . import pathfinders
