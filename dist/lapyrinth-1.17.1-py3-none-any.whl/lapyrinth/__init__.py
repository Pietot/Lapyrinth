"""Top-level package for Lapyrinth."""

from . import pathfinders
from .lapyrinth import Maze

__all__ = ["Maze", "pathfinders"]
