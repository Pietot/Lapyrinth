from .lapyrinth import Maze
from . import lapyrinth
from . import pathfinders
